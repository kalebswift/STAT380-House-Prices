#!/bin/bash


Rscript src/your_scripts.R
